# Instrucciones de diseño permanentes · Mi Libro de Notas

Estas reglas las fijó Javier a lo largo del desarrollo (v2.0 → v2.66). **Todo cambio a la app debe respetarlas.**
Si una petición nueva choca con alguna, preguntar antes de cambiarla.

## 1. Plataforma y forma de la app
1. **Portátil:** un solo archivo HTML, JavaScript puro, sin librerías externas, sin CDN, sin servidor. Todo dentro del
   aparato.
2. **iPad + Safari** es la plataforma principal (también iPhone). Se usa con el dedo y con **Stage Manager**.
3. **Abre y funciona sin internet**, desde la copia del aparato. Internet solo hace falta para Conversa.
4. Debe sentirse como la app **Notas de iOS** y organizarse como **JW Library** (libro → capítulo → notas por versículo).
5. PWA con ícono propio (libro abierto con pluma, en plata). Se publica siempre en la **misma dirección**.

## 2. Pantalla y navegación
6. **Todos los botones y ajustes del lado izquierdo.** Línea divisora arrastrable entre panel y nota, y panel plegable,
   para dar a la nota el mayor espacio.
7. En Stage Manager, los controles de la ventana no deben tapar botones: dejar un hueco a la izquierda (120 px,
   ajustable 0–200) **solo cuando la app está en ventana**.
8. En cada capítulo, las notas van **numeradas en orden de versículo**, con color o estilo distinto para distinguirlas.
9. **Al girar la tableta** (leyendo o editando) la pantalla no se mueve ni regresa al inicio: se queda en el mismo
   renglón y cursor.
10. **Deslizar** la nota pasa a la nota siguiente/anterior (aunque esté en otro capítulo), **solo dentro del mismo
    libro**; en la columna izquierda, deslizar pasa de capítulo.
11. Botones de **44 px** o más. Nada debe tapar el texto ni la barra (reproductor, etiquetas del hosting).

## 3. Edición y selección táctil
12. La nota se abre en **modo lectura** con botón **Editar**. En Editar, la barra de letras va **a la izquierda** de la
    nota.
13. **El teclado nunca aparece solo**; solo con el botón ⌨️. Sin teclado, la zona de texto es `contenteditable="false"`
    para que el dedo seleccione palabras.
14. Cada herramienta usa **solo la selección recién hecha** (o la que el iPad borró hace menos de 2.5 s). Nunca
    reaplicar una selección vieja. Sin selección, A+/A−/Aa actúan sobre el **párrafo tocado** con un destello.
15. Barra de letras: ↶ ↷ (60 pasos por zona), N, C, S, **Ma (manuscrita en lugar del tachado)**, A+ / A− / A, Aa
    (MAYÚSCULAS ↔ minúsculas), **10 colores de letra y 10 de resaltado desplegados dentro de la misma barra** junto
    al botón tocado (no en panel aparte), ✕ Soltar, TODO, Copiar/Cortar/Pegar, 📝 A BOSQUEJO, QUITAR.
16. Botones con `touch-action:manipulation; user-select:none`; tamaño de letra en `em`, **nunca `zoom`** en texto que
    se selecciona.
17. **Guardado automático** con indicador «Guardado ✓» (sin botón Guardar). Nada que trabe al escribir: no reescribir
    todo en cada tecla.
18. Funciones nuevas sin **nombres repetidos** (en JavaScript una función repetida reemplaza a otra sin avisar).

## 4. Texto bíblico y citas
19. La app no trae la TNM: se carga desde el **EPUB de la TNM de jw.org** dentro del aparato.
20. El texto bíblico debe **verse solo, sin tocar botones**: el versículo de la nota en un recuadro y bajo cada
    «Versículo N» del capítulo.
21. Toda **cita escrita en una nota es tocable** y muestra el versículo, como en JW Library: libros abreviados o con
    número («1 Cor.», «primera Cor», «uno Cor»), listas («1:6, 7»), rangos, capítulos completos, y aunque solo
    aparezcan los números, **deduciendo el libro por el contexto**. No confundir horas, años ni cantidades.

## 5. Lectura en voz alta y Conversa
22. Al seleccionar TODO (o 🔊 Escuchar) se lee la nota en voz alta; debe **seguir con la pantalla apagada** o al
    cambiar de app, pausar en cualquier momento y **reanudar en el punto exacto**.
23. La voz **no debe sonar robótica**: en Mi Libro de Notas se usa la voz «Mejorada/Premium» elegida en el iPad
    (sin selector propio en la app).
24. **Conversa** vive en el mismo sitio (`conversa.html`), **solo lee** notas y TNM (nunca las modifica) y la IA solo
    recibe las notas elegidas o buscadas.
25. Al mandar una nota a Conversa, la **lee de inmediato con el micrófono cerrado**; al regresar, Mi Libro de Notas
    vuelve **exactamente a la misma nota y lugar**.

## 6. Datos, respaldo y espacio
26. Notas en **IndexedDB del aparato** (no depender de localStorage). No cambiar claves de almacenamiento existentes.
27. **Un solo respaldo** con nombre fijo (`mi-libro-de-notas-respaldo.json`) que sustituye al anterior (Reemplazar), en
    una carpeta especial indicada de forma visible. Un solo panel «Respaldo y sincronización».
28. **Los respaldos nuevos se guardan solos y los viejos se borran solos** (copias internas: 7, 14 o 30).
29. El respaldo y las copias llevan **todo**: notas, repaso, bosquejos y discursos.
30. Nada se borra para siempre de golpe: **Papelera de 30 días** y copia «antes de…» en restaurar, leer respaldo,
    sincronizar y revisar notas.
31. Mostrar el **espacio real** del aparato y pedir que los datos sean **permanentes**; avisar antes de llenarse.
32. Revisar de vez en cuando **notas repetidas o mal ubicadas** y permitir reubicarlas; nada cambia sin que el usuario
    lo toque.
33. Poder **eliminar una nota desde la lista** de la columna izquierda (con confirmación y Deshacer).

## 7. Forma de entregar cada versión
34. Subir la versión en `index.html`, `conversa.html` (si cambia), `sw.js` y agregar arriba del `CHANGELOG.md` lo que
    cambió, en palabras sencillas.
35. Cada entrega lleva **informe de auditoría**: sintaxis, revisión en iPad/iPhone, datos guardados, errores
    encontrados y corregidos, y qué debe probar Javier.
36. Probar con Playwright (`hasTouch`) en iPad horizontal, iPad vertical e iPhone; el probador debe ser distinto de
    quien hizo los cambios.
